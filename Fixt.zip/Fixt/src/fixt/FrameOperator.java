/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.swing.JFrame;

/**
 *
 * @author Bartu
 */
public class FrameOperator {
    
    private static boolean fLoginIsOpen = false;
    private static boolean fSignupIsOpen = false;
    private static boolean fCustomerHomepageIsOpen = false;
    private static boolean fCustomerIssueFormIsOpen = false;
    private static boolean fCustomerIssueCheckAssistantsIsOpen = false;
  
    static final Map<String,JFrame> frameList = new HashMap<>();
    
    private final String fLogin = "Login";
    private final String fSignup = "Signup";
    private final String fCustomerHomepage = "CustomerHomepage";
    private final String fCustomerIssueForm = "CustomerIssueForm";
    private final String fCustomerIssueCheckAssistants = "CustomerIssueCheckAssistants";
    
    
    public FrameOperator(String fName, JFrame frame)
    {        
        System.out.println(fName +"  "+ frame.getName());
        frameList.put(fName, frame);
    }
    
    public void addFrame(String fName, JFrame frame)
    {
        frameList.put(fName, frame);
        //frame.setVisible(true);
    }
    
    
    public boolean frameExists(String fName)
    {
        if(frameList.get(fName) == null)
        {
            System.out.println("DOESNT EXIST");
            return false;
        }
        return true;
        
    }
    
    public void openFrame(String fName, String curFrame)
    {
        System.out.println("Opening frame " + fName);
        
        if(fName.equalsIgnoreCase(fSignup))
        {
            if(fSignupIsOpen != true)
                {
                    frameList.get(fName).setVisible(true);
                    fSignupIsOpen = true;
                    frameList.get(fName).setLocation(frameList.get(curFrame).getX(), frameList.get(curFrame).getY());
                    frameList.get(curFrame).setVisible(false);
                    fLoginIsOpen = false;
                    
                    closeFrame(curFrame);
                    return;
                }
        }
        if(fName.equalsIgnoreCase(fLogin))
        {
            if(fLoginIsOpen != true)
            {               
                frameList.get(fName).setVisible(true);
                fLoginIsOpen = true;
                frameList.get(fName).setLocation(frameList.get(curFrame).getX(), frameList.get(curFrame).getY());
                frameList.get(curFrame).setVisible(false);
                
                closeFrame(curFrame);
                return;
            }           
        }
        if(fName.equalsIgnoreCase(fCustomerHomepage))
        {
            if(fCustomerHomepageIsOpen != true)
            {               
                frameList.get(fName).setVisible(true);
                fLoginIsOpen = true;
                frameList.get(fName).setLocation(frameList.get(curFrame).getX(), frameList.get(curFrame).getY());
                frameList.get(curFrame).setVisible(false);
                
                closeFrame(curFrame);
                return;
            }           
        }
        if(fName.equalsIgnoreCase(fCustomerIssueForm))
        {
            if(fCustomerIssueFormIsOpen != true)
            {               
                frameList.get(fName).setVisible(true);
                fCustomerIssueFormIsOpen = true;
                frameList.get(fName).setLocation(frameList.get(curFrame).getX(), frameList.get(curFrame).getY());
                frameList.get(curFrame).setVisible(false);
                
                closeFrame(curFrame);
                return;
            }           
        }
        if(fName.equalsIgnoreCase(fCustomerIssueCheckAssistants))
        {
            if(fCustomerIssueCheckAssistantsIsOpen != true)
            {               
                frameList.get(fName).setVisible(true);
                fCustomerIssueFormIsOpen = true;
                frameList.get(fName).setLocation(frameList.get(curFrame).getX(), frameList.get(curFrame).getY());
                frameList.get(curFrame).setVisible(false);
                
                closeFrame(curFrame);
                return;
            }           
        }
        
        
        /*if(fName.equalsIgnoreCase(fItemOptions))
        {
            if(fItemOptionsIsOpen != true)
                {
                    frameList.get(fItemOptions).setVisible(true);
                    fItemOptionsIsOpen = true;
                    return;
                }
        }   */
        
    }

//-----CLOSE-PROVIDED-FRAME---------------------------------------------------   
    public void closeFrame(String fName)
    {
        switch(fName){
            
            case fLogin:
                frameList.get(fName).dispose();
                frameList.remove(fName);
                fLoginIsOpen = false;
                break;
                
            case fSignup:
                frameList.get(fName).dispose();
                frameList.remove(fName);
                fSignupIsOpen = false;
                break;
                
            case fCustomerHomepage:
                frameList.get(fName).dispose();
                frameList.remove(fName);
                fCustomerHomepageIsOpen = false;
                break;
            case fCustomerIssueForm:
                frameList.get(fName).dispose();
                frameList.remove(fName);
                fCustomerIssueFormIsOpen = false;
                break;  
                
            case fCustomerIssueCheckAssistants:
                frameList.get(fName).dispose();
                frameList.remove(fName);
                fCustomerIssueCheckAssistantsIsOpen = false;
                break;    
            /*case fOptions:
                if(fOptionsIsOpen == true)
                {
                    closeFrame(fItemOptions);
                    closeFrame(fCategoryOptions);
                    frameList.get(fName).dispose();
                    frameList.remove(fName);
                    fOptionsIsOpen = false;
                    break;
                }
            case fItemOptions:
                if(fItemOptionsIsOpen == true)
                {
                    frameList.get(fName).dispose();
                    frameList.remove(fName);
                    fItemOptionsIsOpen = false;
                    break;
                }
            case fCategoryOptions:
                if(fCategoryOptionsIsOpen == true)
            {
                /*
                frameCategoryOptions frame = new frameCategoryOptions();
                frame.dispose();
                frameClosed(fCategoryOptions);
                return;
                
            }*/
        } 
    }
}
