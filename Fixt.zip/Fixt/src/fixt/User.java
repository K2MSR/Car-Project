//  
//  User class file
//

package fixt;

/**
 *
 * @author Bartu
 */
public class User {
    
    protected String uid;
    protected String upassword;
    protected String fname;
    protected String lname;
    protected String email;
    protected String dob;
    protected String pimage;
    protected String atype;
    protected String randsalt;
    
    public User(String uid, String upassword, String fname, String lname, String dob, String email, String pimage, String atype, String randsalt)
    {
        this.uid = uid;
        this.upassword = upassword;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.dob = dob;
        this.pimage = pimage;
        this.atype = atype;
        this.randsalt = randsalt;
    }
    
    public User(String uid, String fname, String lname, String dob, String email, String pimage, String atype)
    {
        this.uid = uid;
        this.upassword = null;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.dob = dob;
        this.pimage = pimage;
        this.atype = atype;
        this.randsalt = null;
    }  
}
