//=============================================================================
//    FieldInterface.java Class File
//=============================================================================  
//
//  This class provides the following utilities:
//  - Set placeholders for text/password fields
//  - Fill in large amount of data to a combobox
//



package fixt;
import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.*;

/**
 *
 * @author Bartu
 */
public class FieldInterface {
    public FieldInterface()
    {
        
    }
    public void setPlaceholder(JTextField tf, String text)
    {
        tf.setText(text);
        tf.setForeground(Color.GRAY);
        tf.addFocusListener(new FocusListener() {
        @Override
        public void focusGained(FocusEvent e) {
            if (tf.getText().equals(text)) {
                tf.setText("");
                tf.setForeground(Color.BLACK);
            }
        }
        @Override
        public void focusLost(FocusEvent e) {
            if (tf.getText().isEmpty()) {
                tf.setForeground(Color.GRAY);
                tf.setText(text);
            }
        }
        });
    }
     public void setPlaceholder(JTextArea ta, String text ,boolean wrapText)
    {
        ta.setText(text);
        ta.setForeground(Color.GRAY);
        ta.addFocusListener(new FocusListener() {
        @Override
        public void focusGained(FocusEvent e) {
            if (ta.getText().equals(text)) {
                ta.setText("");
                ta.setForeground(Color.BLACK);
            }
        }
        @Override
        public void focusLost(FocusEvent e) {
            if (ta.getText().isEmpty()) {
                ta.setForeground(Color.GRAY);
                ta.setText(text);
            }
        }
        });
        
        if(wrapText)
        {
            ta.setLineWrap(true);
            ta.setWrapStyleWord(true);
        }
    }
    public void setPlaceholder(JPasswordField pf, String text)
    {
        pf.setText(text);
        pf.setForeground(Color.GRAY);
        pf.addFocusListener(new FocusListener() {
        @Override
        public void focusGained(FocusEvent e) {

            if (new String(pf.getPassword()).equals(text)) {
                pf.setText("");
                pf.setForeground(Color.BLACK);
            }
        }
        @Override
        public void focusLost(FocusEvent e) {
            if (pf.getText().isEmpty()) {
                pf.setForeground(Color.GRAY);
                pf.setText(text);
            }
        }
        });
    }
    
    public void fillComboBox(JComboBox cb, int base, int top, String placeholder, boolean ascending)
    {    
        //----- Swap numbers to prevent errors --------------------------------
        if(top < base)
        {
            int  temp = base;
            base = top;
            top = temp;
        }
        
        //----- Initialize the array to store items ---------------------------
        String[] itemArray = new String[(top - base) + 2];
        itemArray[0] = placeholder;
        int arrIndex = 1;
        
        //----- Insert in ascending order -------------------------------------
        if(ascending)
        {
            while(base <= top)
            {
                itemArray[arrIndex] = Integer.toString(base);
                arrIndex++;
                base++;
            }        
            cb.setModel(new DefaultComboBoxModel(itemArray));
        }
        //----- Insert in descending order ------------------------------------
        if(!ascending)
        {
            while(top >= base)
            {
                itemArray[arrIndex] = Integer.toString(top);
                arrIndex++;
                top--;
            }        
            cb.setModel(new DefaultComboBoxModel(itemArray));
        }
        
    }
    
    
    
   
}
