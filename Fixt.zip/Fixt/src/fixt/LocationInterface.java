package fixt;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

/**
 *
 * @author Bartu
 */
public class LocationInterface {
    //----- Variable generation limits based on borders of Australia ----------
    private double latitudeUpper    = -17.7;
    private double latitudeLower  = -37.0;
    private double longitudeUpper   = 115.1;
    private double longitudeLower   = 151.0;
    public LocationInterface() {
        
    }
      
    public double generateLatitude() {
        Random r = new Random();
        double randomLatitude = latitudeLower + (latitudeUpper - latitudeLower) * r.nextDouble(); 
        
        BigDecimal bd = new BigDecimal(Double.toString(randomLatitude));
        bd = bd.setScale(6, RoundingMode.HALF_UP);
        
        return bd.doubleValue();
    }   
    public double generateLongitude(){
        Random r = new Random();
        double randomLongitude = longitudeLower + (longitudeUpper - longitudeLower) * r.nextDouble();    
        
        BigDecimal bd = new BigDecimal(Double.toString(randomLongitude));
        bd = bd.setScale(6, RoundingMode.HALF_UP);
        
        return bd.doubleValue();
    }
}
