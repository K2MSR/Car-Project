/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import com.sun.webkit.CursorManager;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author Bartu
 */
public class ButtonAnimations {

    
    public ButtonAnimations()
    {
        
    }
    
    public void setButtonImages(Icon Default, Icon Pressed, Icon Hover, JButton button)
    {
         button.addMouseListener(new MouseAdapter(){
            boolean mouseIsInside = false;
            @Override
            public void mousePressed(MouseEvent me)
            {
                button.setIcon(Pressed);
                mouseIsInside = true;
            }
            @Override
            public void mouseReleased(MouseEvent me)
            {
                if(mouseIsInside == false)
                {
                    button.setIcon(Default);
                    return;
                }
                else
                    button.setIcon(Hover);
            }
            
            @Override
            public void mouseEntered(MouseEvent me)
            {
                button.setIcon(Hover);
                mouseIsInside = true;
                button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override
            public void mouseExited(MouseEvent me)
            {
                button.setIcon(Default);
                mouseIsInside = false;
            }
        });
    }
    
    public void setButtonImages(Icon Default, Icon Pressed, Icon Hover, JLabel button)
    {
        button.addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed(MouseEvent me)
            {
                button.setIcon(Pressed);
            }
            @Override
            public void mouseReleased(MouseEvent me)
            {
                button.setIcon(Default);
            }
            
            @Override
            public void mouseEntered(MouseEvent me)
            {
                button.setIcon(Hover);
                button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override
            public void mouseExited(MouseEvent me)
            {
                button.setIcon(Default);
            }
        });
    }
    
    
    
    
}
