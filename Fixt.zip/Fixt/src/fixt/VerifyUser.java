/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;
import java.math.BigInteger; 
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

/**
 *
 * @author Bartu
 */
public class VerifyUser {
    DBConnect db = new DBConnect();
    Security sec = new Security();
    
    private String uid;
    private String password;

    public VerifyUser(String uid, String password) throws NoSuchAlgorithmException
    {
        this.uid = uid;
        this.password = password;
    }
    
    public boolean verify() throws NoSuchAlgorithmException
    {
        User userdata = db.fetchUser(uid);
        
        if(userdata == null)
        {
            return false;
        }
        
        String saltedpw = sec.hashString(password + userdata.randsalt);

        if(compare(saltedpw, userdata.upassword) == true)
        {
            System.out.println("USER GRANTED!");
            return true;
        }
        return false;
    }
    
    private boolean compare(String password, String dbPassword)
    {
        return password.equals(dbPassword);  
    }
    
    
    
}