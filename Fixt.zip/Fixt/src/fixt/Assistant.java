//
//  Assistant class file
//  Shares variables with User class
//
package fixt;

/**
 *
 * @author Bartu
 */
public class Assistant extends User {
    protected double curLatitude;
    protected double curLongitude;
    
    public Assistant(String uid, String fname, String lname, String dob, String email, String pimage, String atype, double curLatitude, double curLongitude) {
        super(uid, fname, lname, dob, email, pimage, atype);
        this.curLatitude = curLatitude;
        this.curLongitude = curLongitude;
    }
    
}
