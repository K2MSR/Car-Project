/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Pattern;

/**
 *
 * @author Bartu
 */
public class DBConnect{
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
            
    public DBConnect(){
        try{
            //----- Create connection -----------------------------------------
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fixtdb?useLegacyDatetimeCode=false&serverTimezone=Australia/Sydney", "root", "");
            st = con.createStatement();
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("ERROR!: " + e);
        }
    }
    
    protected User fetchUser(String uid)
    {
        User user = null;
        try{
            String query = "SELECT * FROM user HAVING uid = '" + uid + "';";
            rs = st.executeQuery(query);
            rs.next();
            System.out.println(rs.getString("uid"));
            user = new User(rs.getString("uid"),
                            rs.getString("upassword"),
                            rs.getString("fname"),
                            rs.getString("lname"),
                            rs.getString("email"),
                            rs.getDate("dob").toString(),
                            rs.getString("pimage"),
                            rs.getString("atype"),
                            rs.getString("randsalt")
            );
        }
        catch(SQLException e)
        {
            System.out.println("Error while fetching user data. " + e);
        }
        return user;
    }
    
    public boolean clientIsSubscribed(String uid){
        try{
            String query = "SELECT COUNT(uid) as ucount FROM subscription WHERE uid = '" + uid +"';";
            rs = st.executeQuery(query);
            rs.next();
            int count = Integer.parseInt(rs.getString("ucount")) ;
            if(count == 1)
                return true;      
        }
        catch(Exception e){
            System.err.println("Error while fetching user data from subscriptions. " + e);
        }
        
        return false;
    }
    
    public String insertUser(User user) throws SQLException, ParseException
    {
        try{
            String query = "INSERT INTO user(uid, upassword, fname, lname, email, dob, atype, randsalt)"
                           +"VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date myDate = formatter.parse(user.dob);
            java.sql.Date dob = new java.sql.Date(myDate.getTime());
            
            PreparedStatement pStatement = con.prepareStatement(query);
            pStatement.setString(1, user.uid);
            pStatement.setString(2, user.upassword);
            pStatement.setString(3, user.fname);
            pStatement.setString(4, user.lname);
            pStatement.setString(5, user.email);
            pStatement.setDate(6, dob);
            pStatement.setString(7, user.atype);
            pStatement.setString(8, user.randsalt);
            
            pStatement.execute();
            
            return "Success";
        }
        catch(SQLException e)
        {
            System.err.println(e);
            if(e.toString().contains("Duplicate entry")){
                return "Username exists";
            }
            else return "Failure"; 
        } 
    }
    
    public void insertServiceRequest(ServiceRequest sr){
        try{

            String query = "INSERT INTO servicerequest(uid, cat, reqdesc, loclatitude, loclongitude)"
                           +"VALUES(?, ?, ?, ?, ?)";

            PreparedStatement pStatement = con.prepareStatement(query);
            pStatement.setString(1, sr.uid);
            pStatement.setString(2, sr.cat);
            pStatement.setString(3, sr.reqDesc);
            pStatement.setDouble(4, sr.locLatitude);
            pStatement.setDouble(5, sr.locLongitude);

            pStatement.execute();
        }catch(SQLException e){
            System.err.println(e);
        } 
    }
    
    
    public void fetchAcceptingAssistants(String uid){
        try{
            String query = "SELECT * FROM acceptingassistant as A"
                           +"INNER JOIN servicerequest as S"
                           +"ON A.id = S.id"
                           +"WHERE A.id = (SELECT id FROM servicerequest"
                                          +"WHERE uid =" + uid + ");";
            
            rs = st.executeQuery(query);
            rs.next();
            
            ArrayList<Assistant> assistantList = new ArrayList<>();
            Statement astatement = con.createStatement();            
            while(rs.next())
            {
                String assistantQuery = "SELECT aid FROM acceptingassistant where uid = '" + uid + "';";
                ResultSet ars = con.createStatement().executeQuery(assistantQuery);
                ars.next();                
                String aid = ars.getString("aid");
                
                String userQuery = "SELECT * FROM user where uid = '" + aid + "';";
                ResultSet urs = con.createStatement().executeQuery(userQuery);
                urs.next();
                
                // CONTINUE FROM CREATING NEW ASSSISTANT DATA AND ADDING IT TO 
                // THE ARRAYLIST
                
                //assistantList.add(new Assistant())
            }
            /*String query = "SELECT * FROM servicerequest WHERE uid = '" + uid + "';";
            rs = st.executeQuery(query);
            rs.next();
            
                    
            String query = "SELECT COUNT(uid) as ucount FROM `subscription` WHERE uid = '" + uid +"';";
            rs = st.executeQuery(query);
            rs.next();
            int count = Integer.parseInt(rs.getString("ucount")) ;
            if(count == 1)
                return true;              
                    */
                    
        }catch(Exception e){
            System.err.println("Error while fetching assistants. " + e);
        }
    }
    
    protected void execDeleteQuery(String query, String parameter){
        try{
            PreparedStatement pStatement = con.prepareStatement(query);
            pStatement.setString(1, parameter);
            pStatement.execute();

        }catch(Exception e){
            System.err.println(e);
        }
    }
    

    protected void close(){
        try{
            con.close();
        }catch(SQLException e){
            System.err.println(e);
        }
        
    }
    
   
    
}
