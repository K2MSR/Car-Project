/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatterFactory;

/**
 *
 * @author Bartu
 */
public class Signup extends javax.swing.JFrame {

    
    //-----VARIABLE-AND-OBJECT-DECLARATIONS------------------------------------/
    private final FrameOperator fOperator = new FrameOperator("Signup", this); 
    private final Security sec = new Security();
    private final DBConnect db = new DBConnect();
    private final FieldInterface fieldinterface = new FieldInterface();
    private final String rgx = "(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*:(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)(?:,\\s*(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*))*)?;\\s*)";
    
    private int posX, posY;
    
    public Signup() {
        this.setUndecorated(true);
        this.setResizable(false);         
        initComponents();
        addButtonStyles();
        setInputPlaceholder();
        this.setIconImage(new ImageIcon(getClass().getResource("assets/Icon.png")).getImage());       
        this.setTitle("FIXT Road Services - Signup");
        //centerFrame();
       
        buttonOnClickActions();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_panel = new javax.swing.JLayeredPane();
        field_fname = new javax.swing.JTextField();
        field_lname = new javax.swing.JTextField();
        field_id = new javax.swing.JTextField();
        field_pw = new javax.swing.JPasswordField();
        field_email = new javax.swing.JTextField();
        combo_acctype = new javax.swing.JComboBox<>();
        label_id = new javax.swing.JLabel();
        label_pw = new javax.swing.JLabel();
        label_fname = new javax.swing.JLabel();
        label_lname = new javax.swing.JLabel();
        label_email = new javax.swing.JLabel();
        label_dob = new javax.swing.JLabel();
        label_acctype = new javax.swing.JLabel();
        button_signup = new javax.swing.JButton();
        label_exit = new javax.swing.JLabel();
        label_minimize = new javax.swing.JLabel();
        label_back = new javax.swing.JLabel();
        combo_day = new javax.swing.JComboBox<>();
        combo_month = new javax.swing.JComboBox<>();
        combo_year = new javax.swing.JComboBox<>();
        label_background = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(440, 720));
        setMinimumSize(new java.awt.Dimension(440, 720));
        setSize(new java.awt.Dimension(440, 720));

        main_panel.setPreferredSize(new java.awt.Dimension(440, 720));

        field_fname.setText("First Name");
        field_fname.setPreferredSize(new java.awt.Dimension(175, 40));

        field_lname.setText("Surname");
        field_lname.setPreferredSize(new java.awt.Dimension(175, 40));

        field_id.setText("Username");
        field_id.setPreferredSize(new java.awt.Dimension(360, 40));

        field_pw.setText("Password");
        field_pw.setMinimumSize(new java.awt.Dimension(360, 40));
        field_pw.setPreferredSize(new java.awt.Dimension(360, 40));

        field_email.setText("E-mail Address");

        combo_acctype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Account Type", "Customer", "Service Provider" }));
        combo_acctype.setSelectedIndex(0);
        combo_acctype.setMaximumSize(new java.awt.Dimension(360, 40));
        combo_acctype.setMinimumSize(new java.awt.Dimension(360, 40));
        combo_acctype.setPreferredSize(new java.awt.Dimension(360, 40));

        label_id.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_id.setForeground(new java.awt.Color(255, 255, 255));
        label_id.setText("Account ID:");

        label_pw.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_pw.setForeground(new java.awt.Color(255, 255, 255));
        label_pw.setText("Account Password:");

        label_fname.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_fname.setForeground(new java.awt.Color(255, 255, 255));
        label_fname.setText("Name:");

        label_lname.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_lname.setForeground(new java.awt.Color(255, 255, 255));
        label_lname.setText("Surname:");

        label_email.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_email.setForeground(new java.awt.Color(255, 255, 255));
        label_email.setText("E-mail Address:");

        label_dob.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_dob.setForeground(new java.awt.Color(255, 255, 255));
        label_dob.setText("Date of Birth:");

        label_acctype.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_acctype.setForeground(new java.awt.Color(255, 255, 255));
        label_acctype.setText("Account Type:");

        button_signup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fixt/assets/signup_default.png"))); // NOI18N
        button_signup.setMaximumSize(new java.awt.Dimension(360, 40));
        button_signup.setMinimumSize(new java.awt.Dimension(360, 40));
        button_signup.setPreferredSize(new java.awt.Dimension(360, 40));

        label_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fixt/assets/exit_default.png"))); // NOI18N

        label_minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fixt/assets/minimize_default.png"))); // NOI18N

        label_back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fixt/assets/back_default.png"))); // NOI18N

        combo_day.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Day", " " }));

        combo_month.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Month", "January", "February", "March", "April", "May", "June", "July", "August", "September", "Ocotober", "November", "December" }));

        combo_year.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Year" }));

        main_panel.setLayer(field_fname, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(field_lname, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(field_id, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(field_pw, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(field_email, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(combo_acctype, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_id, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_pw, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_fname, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_lname, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_email, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_dob, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_acctype, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(button_signup, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_exit, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_minimize, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(label_back, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(combo_day, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(combo_month, javax.swing.JLayeredPane.DEFAULT_LAYER);
        main_panel.setLayer(combo_year, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label_back)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label_minimize)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label_exit)
                .addContainerGap())
            .addGroup(main_panelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addComponent(label_acctype)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                        .addComponent(button_signup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(40, 40, 40))
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(label_dob)
                            .addComponent(label_email)
                            .addComponent(label_pw)
                            .addComponent(label_id)
                            .addGroup(main_panelLayout.createSequentialGroup()
                                .addComponent(combo_day, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(combo_month, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(combo_year, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(field_id, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(field_pw, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(field_email)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                                        .addComponent(field_fname, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                    .addGroup(main_panelLayout.createSequentialGroup()
                                        .addComponent(label_fname)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label_lname)
                                    .addComponent(field_lname, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(combo_acctype, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(label_exit)
                    .addComponent(label_minimize)
                    .addComponent(label_back))
                .addGap(80, 80, 80)
                .addComponent(label_id)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(field_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(label_pw)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(field_pw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_fname)
                    .addComponent(label_lname))
                .addGap(7, 7, 7)
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(field_fname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(field_lname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(label_email)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(field_email, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(label_dob)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(combo_year, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(combo_day)
                    .addComponent(combo_month))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(label_acctype)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(combo_acctype, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(button_signup, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        label_background.setPreferredSize(new java.awt.Dimension(440, 720));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fixt/assets/bg2.png"))); // NOI18N

        javax.swing.GroupLayout label_backgroundLayout = new javax.swing.GroupLayout(label_background);
        label_background.setLayout(label_backgroundLayout);
        label_backgroundLayout.setHorizontalGroup(
            label_backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 440, Short.MAX_VALUE)
            .addGroup(label_backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 420, Short.MAX_VALUE))
        );
        label_backgroundLayout.setVerticalGroup(
            label_backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 720, Short.MAX_VALUE)
            .addGroup(label_backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 720, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(label_background, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(label_background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Signup().setVisible(true);
            }
        });
    }
    
    //===== Center Frame ======================================================
    private void centerFrame()
    {
        Dimension windowSize = getSize();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();
        
        int dx = centerPoint.x - windowSize.width / 2;
        int dy = centerPoint.y - windowSize.height / 2;
        setLocation(dx, dy);
    }
    
    //===== Add Button Styles =================================================
    private void addButtonStyles()
    {
        ButtonAnimations animButton = new ButtonAnimations();
        
        //===== IMAGES ========================================================        
        //----- Signup Button -------------------------------------------------
        ImageIcon signupDefault = new ImageIcon(getClass().getResource("assets/signup_default.png"));         
        ImageIcon signupHover = new ImageIcon(getClass().getResource("assets/signup_hover.png"));             
        ImageIcon signupPressed = new ImageIcon(getClass().getResource("assets/signup_pressed.png"));         
        animButton.setButtonImages(signupDefault, signupPressed, signupHover, button_signup);

        //----- Exit Button ---------------------------------------------------
        ImageIcon exitDefault = new ImageIcon(getClass().getResource("assets/exit_default.png"));         
        ImageIcon exitPressed = new ImageIcon(getClass().getResource("assets/exit_pressed.png"));  
        animButton.setButtonImages(exitDefault, exitPressed, exitDefault, label_exit);
        
        
        //----- Minimize Button -----------------------------------------------
        ImageIcon minimizeDefault = new ImageIcon(getClass().getResource("assets/minimize_default.png"));         
        ImageIcon minimizePressed = new ImageIcon(getClass().getResource("assets/minimize_pressed.png"));  
        animButton.setButtonImages(minimizeDefault, minimizePressed, minimizeDefault, label_minimize);
        
        //----- Back Button ---------------------------------------------------
        ImageIcon backDefault = new ImageIcon(getClass().getResource("assets/back_default.png"));         
        ImageIcon backHover = new ImageIcon(getClass().getResource("assets/back_hover.png"));             
        ImageIcon backPressed = new ImageIcon(getClass().getResource("assets/back_pressed.png"));         
        animButton.setButtonImages(backDefault, backPressed, backHover, label_back);
        
    }
    
    //===== Button On Click Actions ===========================================
    private void buttonOnClickActions()
    {
        //===== Exit ==========================================================
        label_exit.addMouseListener(new MouseAdapter(){
            
            @Override
            public void mouseClicked(MouseEvent me)
            {
                fOperator.closeFrame("Signup");
                System.exit(0);
            }
        });
        
        
        //===== Minimize ======================================================
        label_minimize.addMouseListener(new MouseAdapter(){
            
            @Override
            public void mouseClicked(MouseEvent me)
            {
                 JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(main_panel);
                 topFrame.setState(Frame.ICONIFIED);
            }
        });
        
        //===== Back ==========================================================
        label_back.addMouseListener(new MouseAdapter(){
            
            @Override
            public void mouseClicked(MouseEvent me)
            {
                fOperator.addFrame("Login", new Login());
                 fOperator.openFrame("Login", "Signup");
                 
            }
        });
        
        //===== UI Drag =======================================================
        label_background.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e)
            {
                posX=e.getX();
                posY=e.getY();
            }
        });
        label_background.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent evt)
            {
                //sets frame position when mouse dragged
                setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);
                
            }
        });
        
        //===== Signup ========================================================
        button_signup.addActionListener(new ActionListener(){    
            public void MouseClicked(ActionEvent e)
            {
                
            }

            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                try 
                { 
                    String uid   = field_id.getText().toLowerCase();
                    String fname = field_fname.getText();
                    String lname = field_lname.getText();
                    String email = field_email.getText();
                    String day   = combo_day.getSelectedItem().toString();
                    String month = combo_month.getSelectedItem().toString();
                    String year  = combo_year.getSelectedItem().toString();
                    String atype = combo_acctype.getSelectedItem().toString();
                    
                    //---- Check username -------------------------------------
                    if(uid.equalsIgnoreCase("Username"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please enter your username");
                        return;
                    }
                    else if(!Pattern.matches("^[a-z0-9]{5,20}$",uid))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Username has to be 5 - 20 alpha-numeric characters long.");
                        return;
                    }
                    //----- Check password ------------------------------------
                    else if(new String(field_pw.getPassword()).equalsIgnoreCase("Password"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please enter your password.");
                        return;
                    }
                    else if(!Pattern.matches("^[a-zA-Z0-9]{8,}$", new String(field_pw.getPassword())))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Password needs to be at least 8 characters long.");
                        return;
                    }
                    //----- Check firstname -----------------------------------
                    else if(fname.equalsIgnoreCase("First Name"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please enter your first name");
                        return;
                    }
                    else if(!Pattern.matches("^[a-zA-Z]{2,30}$",fname))
                    {
                        JOptionPane.showMessageDialog(main_panel, "First name has to be 2-30 alphabetical characters.");
                        return;
                    }
                    //----- Check lastname ------------------------------------
                    else if(lname.equalsIgnoreCase("Surname"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please enter your surname.");
                        return;
                    }
                    else if(!Pattern.matches("^[a-zA-Z]{2,30}$",lname))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Surname has to be 2-30 alphabetical characters.");
                        return;
                    }
                    //----- Check e-mail --------------------------------------
                    else if(email.equalsIgnoreCase("E-mail Address"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please enter your e-mail address.");
                        return;
                    }
                    else if(!Pattern.matches(rgx, email))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please use a valid e-mail address.");
                        return;
                    }
                    //----- Check date of birth -------------------------------
                    else if(day.equalsIgnoreCase("Day"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please select your day of birth.");
                        return;
                    }
                    else if(month.equalsIgnoreCase("Month"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please select your month of birth.");
                        return;
                    }
                    else if(year.equalsIgnoreCase("Year"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please select your year of birth.");
                        return;
                    }
                    //----- Check account type --------------------------------
                    else if(atype.equalsIgnoreCase("Account Type"))
                    {
                        JOptionPane.showMessageDialog(main_panel, "Please select the account type.");
                        return;
                    }
                    //----- If all are passed, create user data ---------------
                    else
                    {
                        String salt = sec.generateSalt();
                        String pw   = sec.hashString(new String(field_pw.getPassword()) + salt);
                        String dob  = year + "-" + month + "-" + day;
                        User user = new User(uid,pw, fname, lname, dob, email, null, atype, salt);
                        
                        String dbreply = db.insertUser(user);
                        
                        if(dbreply.equalsIgnoreCase("Success"))
                        {
                            JOptionPane.showMessageDialog(main_panel, "Successfully registered to fixt!\nReturning back to login screen.");
                            fOperator.addFrame("Login", new Login());
                            fOperator.openFrame("Login", "Signup");
                        }
                        if(dbreply.equalsIgnoreCase("Username exists"))
                        {
                            JOptionPane.showMessageDialog(main_panel, "Username already exists.");
                            return;
                        }
                        if(dbreply.equalsIgnoreCase("Failure"))
                        {
                            JOptionPane.showMessageDialog(main_panel, "An error occured while registering. Please try again.");
                            return;
                        }
                    }                    
                } 
                catch (Exception e) {
                    System.err.println(e);
                }   
            }
        });
        
   
    }
    

    private void setInputPlaceholder()
    {
        //===== User Id Input Field ===========================================
        fieldinterface.setPlaceholder(field_id, "Username");
        
        //===== Email Input Field =============================================
        fieldinterface.setPlaceholder(field_email, "E-mail Address");      
        
        //===== Name Field ====================================================
        fieldinterface.setPlaceholder(field_fname, "First Name"); 

        //===== Password Field ================================================
        fieldinterface.setPlaceholder(field_pw, "Password"); 
        
        //===== Surname Field =================================================        
        fieldinterface.setPlaceholder(field_lname, "Surname"); 

        //===== DOB Field =====================================================   
        fieldinterface.fillComboBox(combo_day, 1, 31, "Day", true);
        fieldinterface.fillComboBox(combo_month, 1, 12, "Month", true);
        fieldinterface.fillComboBox(combo_year, 1900, 2019, "Year", false);
        

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton button_signup;
    private javax.swing.JComboBox<String> combo_acctype;
    private javax.swing.JComboBox<String> combo_day;
    private javax.swing.JComboBox<String> combo_month;
    private javax.swing.JComboBox<String> combo_year;
    private javax.swing.JTextField field_email;
    private javax.swing.JTextField field_fname;
    private javax.swing.JTextField field_id;
    private javax.swing.JTextField field_lname;
    private javax.swing.JPasswordField field_pw;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel label_acctype;
    private javax.swing.JLabel label_back;
    private javax.swing.JPanel label_background;
    private javax.swing.JLabel label_dob;
    private javax.swing.JLabel label_email;
    private javax.swing.JLabel label_exit;
    private javax.swing.JLabel label_fname;
    private javax.swing.JLabel label_id;
    private javax.swing.JLabel label_lname;
    private javax.swing.JLabel label_minimize;
    private javax.swing.JLabel label_pw;
    private javax.swing.JLayeredPane main_panel;
    // End of variables declaration//GEN-END:variables
}
