/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 *
 * @author Bartu
 */
public class Security {
    
    public Security()
    {
        
    }
    
    public String generateSalt() throws NoSuchAlgorithmException
    {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[64];
        random.getInstanceStrong().nextBytes(salt);
        System.out.println("SALT:" + salt);
        return salt.toString();
    }
    
    public String hashString(String in) throws NoSuchAlgorithmException
    {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] hashInBytes = sha.digest(in.getBytes(StandardCharsets.UTF_8));
        
        StringBuffer hexString = new StringBuffer();
        for(int i = 0; i < hashInBytes.length; i++)
        {
            String hex = Integer.toHexString(0xff & hashInBytes[i]);
            if(hashInBytes.length == 1)
                hexString.append('0');
            hexString.append(hex);
        }
        
        return hexString.toString();      
    }
}
