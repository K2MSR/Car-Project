/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

/**
 *
 * @author Bartu
 */
public class ServiceRequest {
    protected String uid;
    protected String cat;
    protected String reqDesc;
    protected double locLatitude;
    protected double locLongitude;
    
    public ServiceRequest(String uid, String cat, String reqDesc, double locLatitude, double locLongitude) {
        this.uid = uid;
        this.cat = cat;
        this.reqDesc = reqDesc;
        this.locLatitude = locLatitude;
        this.locLongitude = locLongitude;
    }
}
