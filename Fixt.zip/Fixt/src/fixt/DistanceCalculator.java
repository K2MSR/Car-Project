/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixt;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author Bartu
 */
public class DistanceCalculator {
    private final static double AVERAGE_RADIUS_OF_EARTH = 6371;
    
    public DistanceCalculator()
    {
        
    }

    public double calculateDistance(double currentLatitude, double currentLongitude, double destinationLatitude, double destinationLongitude) 
    {
        double latDistance = Math.toRadians(currentLatitude - destinationLatitude);
        double lngDistance = Math.toRadians(currentLongitude - destinationLongitude);

        double a = (Math.sin(latDistance / 2) * Math.sin(latDistance / 2)) +
                   (Math.cos(Math.toRadians(currentLatitude))) *
                   (Math.cos(Math.toRadians(destinationLatitude))) *
                   (Math.sin(lngDistance / 2)) *
                   (Math.sin(lngDistance / 2));
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        BigDecimal bd = new BigDecimal(Double.toString(AVERAGE_RADIUS_OF_EARTH * c));
        bd = bd.setScale(1, RoundingMode.HALF_UP);

        return bd.doubleValue();
    }
}




